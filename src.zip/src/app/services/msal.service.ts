import { Injectable } from '@angular/core';
import * as Msal from 'msal';

@Injectable({
  providedIn: 'root'
})
export class MsalService {
  authority: string;
  tenantConfig;
  clientApplication: Msal.UserAgentApplication;

  constructor() {
    this.tenantConfig = {
      tenant: 'neutimu.onmicrosoft.com',
      clientID: '3527c3fd-ae76-4ff7-bd1f-27da69f11bb9', //This is your client ID
      defaultAuthority: "https://login.microsoftonline.com/common",  //Default authority value is https://login.microsoftonline.com/common
      //signup
      SignInSignUpauthority: "https://login.microsoftonline.com/tfp/neutimu.onmicrosoft.com/B2C_1_signupsignin2",  //Default authority value is https://login.microsoftonline.com/common
      signUpSignInPolicy: 'B2C_1_signupsignin2',
      gmailSignInPolicy: 'B2C_1_gmailsignin',
       b2cScopes: ["profile"],
  
    }
    this.authority = "https://login.microsoftonline.com/tfp/" + this.tenantConfig.tenant + "/" + this.tenantConfig.signUpSignInPolicy;
    clientApplication: Msal.UserAgentApplication;
  
    this.clientApplication = new Msal.UserAgentApplication(
      this.tenantConfig.clientID, this.authority,
      function (errorDesc: any, token: any, error: any, tokenType: any) {
        // Called after loginRedirect or acquireTokenPopup
        this.clientApplication.acquireTokenSilent(this.tenantConfig.b2cScopes).then(
          function (accessToken: any) {
              this.saveAccessTokenToCache(accessToken);
          }, function (error: any) {
              this.clientApplication.acquireTokenPopup(this.tenantConfig.b2cScopes).then(
                  function (accessToken: any) {
                      this.saveAccessTokenToCache(accessToken);
                  }, function (error: any) {
                      alert("Error acquiring the popup:\n" + error);
                  });
          })
      }
    );
  }
  public login(): void {
    var _this = this;
    this.clientApplication.loginRedirect(this.tenantConfig.b2cScopes);
}

saveAccessTokenToCache(accessToken: string): void {
    // sessionStorage.setItem(this.B2CTodoAccessTokenKey, accessToken);
};

logout(): void {
    this.clientApplication.logout();
};

isOnline(): boolean {
    return this.clientApplication.getUser() != null; 
};
getUser(){
  return this.clientApplication.getUser();
}

}
