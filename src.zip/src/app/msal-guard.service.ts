import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router/src/utils/preactivation';

@Injectable({
  providedIn: 'root'
})
export class MsalGuardService implements CanActivate {
  path;
  route;
  user: any;

  constructor() { }
  canActivate(){
    return this.user.authenticated;
  }
}
